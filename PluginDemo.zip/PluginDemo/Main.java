package plugins.PluginDemo;

import Plugin.Plugin;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;


public class Main implements Plugin {
    @Override
    public String getName(){
        return "demo插件";
    }
    @Override
    public Node getContent(){
        // 创建插件的内容
        VBox content = new VBox();
        Label label = new Label("demo");
        content.getChildren().add(label);

        return  content;
    }
}
